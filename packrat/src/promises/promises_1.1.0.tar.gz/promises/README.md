# promises

[![Build Status](https://travis-ci.org/rstudio/promises.svg?branch=master)](https://travis-ci.org/rstudio/promises)

A promise library for R. https://rstudio.github.io/promises

## Installation

```r
install.packages("promises")
```

To use promises with Shiny, make sure you have Shiny v1.1.0 or later.

## License

MIT
