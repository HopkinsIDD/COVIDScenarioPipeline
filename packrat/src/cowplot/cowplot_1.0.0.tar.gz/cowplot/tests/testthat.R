library(testthat)
library(cowplot)

test_check("cowplot")
