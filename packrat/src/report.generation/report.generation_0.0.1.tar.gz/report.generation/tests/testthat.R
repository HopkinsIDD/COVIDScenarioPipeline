library(testthat)
library(report.generation)

test_check("report.generation")
