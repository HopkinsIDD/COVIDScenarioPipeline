rectangle.window <- function (n)
  rep (1, n)
