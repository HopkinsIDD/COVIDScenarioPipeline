#' Generate isolines and isobands
#'
#' @name isoband
#' @docType package
#' @useDynLib isoband, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom utils modifyList
#' @import grid
NULL

