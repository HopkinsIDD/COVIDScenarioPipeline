library(testthat)
library(raster)

test_check("raster")
