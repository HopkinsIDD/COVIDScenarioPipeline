library(testthat)
library(covidcommon)

test_check("covidcommon")
