library(testthat)
library(inference)

test_check("inference")
