# MMWRweek 0.1.3

* Added a `NEWS.md` file to track changes to the package.
* MMWRweekday() now deals with days of the week in non-US locales.
