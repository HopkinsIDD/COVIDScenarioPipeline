

def _hidden():
  return 42

def add(x, y):
  return x + y
  
