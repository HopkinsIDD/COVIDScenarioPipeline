if (window.jQuery){
  $(document).ready(function() {
    $(".tabwid > .table").removeClass("table");
  });
}

