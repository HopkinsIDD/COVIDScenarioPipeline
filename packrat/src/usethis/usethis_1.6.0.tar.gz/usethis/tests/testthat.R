library(testthat)
library(usethis)

test_check("usethis")
