# Vignettes that take a long time to run will been precompiled

library(knitr)
knit("correlation-utils.Rmd.orig", "correlation-utils.Rmd")
