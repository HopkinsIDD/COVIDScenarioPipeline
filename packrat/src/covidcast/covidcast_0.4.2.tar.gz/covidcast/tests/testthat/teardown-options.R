# see setup-options.R
options(.defaultStringsAsFactors)
