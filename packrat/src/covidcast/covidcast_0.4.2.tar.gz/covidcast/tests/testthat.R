library(testthat)
library(covidcast)

test_check("covidcast")
