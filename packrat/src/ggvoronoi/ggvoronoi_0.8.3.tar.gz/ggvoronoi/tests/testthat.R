library(testthat)
library(ggvoronoi)

test_check("ggvoronoi")
