library(testthat)
library(splines2)


test_check("splines2")
