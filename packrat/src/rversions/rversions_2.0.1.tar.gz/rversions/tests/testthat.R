library(testthat)
library(rversions)

test_check("rversions")
