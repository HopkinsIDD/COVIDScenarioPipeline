<!-- badges: start -->
[![CRAN status](https://www.r-pkg.org/badges/version/globaltoolboxlite)](https://cran.r-project.org/package=globaltoolboxlite)
[![Build Status](https://travis-ci.org/HopkinsIDD/globaltoolboxlite.svg?branch=master)](https://travis-ci.org/HopkinsIDD/globaltoolbox)
[![Codecov test coverage](https://codecov.io/gh/HopkinsIDD/globaltoolboxlite/branch/master/graph/badge.svg)](https://codecov.io/gh/HopkinsIDD/globaltoolboxlite?branch=master)
<!-- badges: end -->

# globaltoolboxlite

## Installation

Install the globaltoolbox package from github:

```{r}
devtools::install_github("HopkinsIDD/globaltoolboxlite")
```

