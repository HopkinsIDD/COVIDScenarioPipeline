library(testthat)
library(ggsignif)

test_check("ggsignif")
