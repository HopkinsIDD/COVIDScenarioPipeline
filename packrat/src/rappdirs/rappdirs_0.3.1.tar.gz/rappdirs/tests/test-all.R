library(testthat)
test_check("rappdirs")

