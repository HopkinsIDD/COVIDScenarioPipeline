library(testthat)
library(hospitalization)

test_check("hospitalization")
