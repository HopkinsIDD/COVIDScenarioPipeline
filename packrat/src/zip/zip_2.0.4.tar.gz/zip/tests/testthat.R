library(testthat)
library(zip)

test_check("zip")
