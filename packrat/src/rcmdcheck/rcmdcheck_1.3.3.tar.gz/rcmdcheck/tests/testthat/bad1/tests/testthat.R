library(testthat)
library(badpackage)

test_check("badpackage")
