library(testthat)
library(rcmdcheck)

test_check("rcmdcheck")
