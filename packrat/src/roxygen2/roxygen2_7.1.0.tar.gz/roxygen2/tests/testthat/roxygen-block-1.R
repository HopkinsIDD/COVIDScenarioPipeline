##' Title
##'
##' Description
##'
##' Details
##'
##' @param x,y,z Descriptions for x, y, z
##' @param a Description of a
##' @param b
##'   Description of b
##' @section Important:
##' Don't run with scissors!
##' @export
