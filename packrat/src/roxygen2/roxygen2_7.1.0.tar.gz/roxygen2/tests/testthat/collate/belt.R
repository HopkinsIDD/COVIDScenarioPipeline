# The space before @ is missing on purpose (#342).
#'@include pants.R
#'@include shirt.R
NULL
